import { useState, useEffect } from "react";
import { usePanier } from '../../../../states';
import "./PremiumTablesRow.css";
import { EventBean, PlaceBean } from "../../../../states/stateModels";

//const seatsNumbers: number[] = Array.from({ length: 12 }, (_, i) => i + 1);


 const tableList = [
  {table:'1',nbchair:6},
  {table:'2',nbchair:6},
  {table:'3',nbchair:6},
  {table:'4',nbchair:6},
  {table:'5',nbchair:6},
  {table:'6',nbchair:6},
  {table:'7',nbchair:6},
  {table:'8',nbchair:6},
  {table:'9',nbchair:6},
  {table:'10',nbchair:6},
  {table:'11',nbchair:6},
  {table:'12',nbchair:6}
];


interface PremiumTablesRowProps {
  onCommande: () => void;
  price: number;
  event: EventBean;
  statePlaces: PlaceBean[];
}

export default function PremiumTablesRow({ onCommande, price, event, statePlaces }: PremiumTablesRowProps) {
  const [selectedSeats, setSelectedSeats] = useState<Record<string, boolean>>({});
  const [selectedTables, setSelectedTables] = useState<number[]>([]);
  const [tableSeats, setTableSeats] = useState<Record<number, Set<number>>>({});
  const { items, addItem, removeItem } = usePanier();


  useEffect(() => {
  const seats: Record<string, boolean> = {};
  const tableSeatCount: Record<number, number> = {};

  // 1️⃣ marquer les chaises sélectionnées
  items.forEach(item => {
    const tableIndex = Number(item.tableNumber) - 1;
    const seatKey = `${tableIndex}-${item.chairNumber}`;

    seats[seatKey] = true;
    tableSeatCount[tableIndex] = (tableSeatCount[tableIndex] || 0) + 1;
  });

  // 2️⃣ activer la table SEULEMENT si toutes les chaises sont prises
  const tables: number[] = [];

  Object.keys(tableSeatCount).forEach(key => {
    const tableIndex = Number(key);
    const tableNum = tableIndex + 1;

    const tablePlaces = statePlaces.filter(
      p => Number(p.tableCode) === tableNum
    );

    const nbSeats = tablePlaces.length || 6;

    if (tableSeatCount[tableIndex] === nbSeats) {
      tables.push(tableIndex); // ✅ table vraiment sélectionnée
    }
  });

  setSelectedSeats(seats);
  setSelectedTables(tables);
}, [items, statePlaces]);
  const removeSeatFromPanier = (table: string, chair: number) => {
  items
    .filter(i => i.tableNumber === table && i.chairNumber === chair)
    .forEach(i => removeItem(i.id));
};

const removeTableFromPanier = (table: string) => {
  items
    .filter(i => i.tableNumber === table)
    .forEach(i => removeItem(i.id));
};




  const tableList = Array.from({ length: 12 }, (_, i) => i + 1); // tables 1 à 12

  const doValidCommande = (table: string, chair: number, priceChair: number) => {
    onCommande();
    addItem({ tableNumber: table, chairNumber: chair, price: priceChair, name: '', quantity: 1, event });
  };

  const handleSeatClick = (tableIndex: number, tableName: string, seatNumber: number, placeStatus: string) => {
  if (placeStatus !== "0") return;

  const key = `${tableIndex}-${seatNumber}`;

  setSelectedSeats(prev => {
    const updated = { ...prev, [key]: !prev[key] };

    if (updated[key]) {
      doValidCommande(tableName, seatNumber, price);
    } else {
      removeSeatFromPanier(tableName, seatNumber);
    }

    return updated;
  });
};


  const handleTableClick = (tableIndex: number, tableName: string, tableStatus: string, nbSeats: number) => {
    if (tableStatus !== "0") return; // seulement table libre peut être sélectionnée
    const isSelected = selectedTables.includes(tableIndex);

    if (isSelected) {
  setSelectedTables(prev => prev.filter(i => i !== tableIndex));

  const seatsToRemove = items.filter(
    i => i.tableNumber === tableName
  );

  setSelectedSeats(prev => {
    const updated = { ...prev };
    seatsToRemove.forEach(i => {
      delete updated[`${tableIndex}-${i.chairNumber}`];
    });
    return updated;
  });

  seatsToRemove.forEach(i => removeItem(i.id));

  setTableSeats(prev => {
    const updated = { ...prev };
    delete updated[tableIndex];
    return updated;
  });

  return;
}

 else {
      setSelectedTables((prev) => [...prev, tableIndex]);

      setSelectedSeats((prevSeats) => {
        const updated = { ...prevSeats };
        const seatsByTable = new Set<number>();

        for (let n = 1; n <= nbSeats; n++) {
          const key = `${tableIndex}-${n}`;
          const place = statePlaces.find(p => p.tableCode === tableName && Number(p.chairCode) === n);
          if (place?.status === "0" && !prevSeats[key]) {
            updated[key] = true;
            seatsByTable.add(n);
            doValidCommande(tableName, n, price);
          }
        }

        setTableSeats((prev) => ({ ...prev, [tableIndex]: seatsByTable }));
        return updated;
      });
    }
  };

  return (
    <div className="premium-cinema">
      <div className="premium-cinema-row">
        {tableList.map((tableNum, index) => {
          const tablePlaces = statePlaces.filter(p => Number(p.tableCode) === tableNum);
          const nbSeats = tablePlaces.length || 6; // si table non existante, nbSeats = 6
          const tableStatus = tablePlaces.length === 0 ? "-1" : tablePlaces[0].status; // -1 = désactivé
          const isTableSelected = selectedTables.includes(index);

          return (
            <div
              key={tableNum}
              className={`premium-table-wrapper ${tableStatus === "-1" ? "disabled" : ""}`}
            >
              <div className="premium-table-code">{tableNum}</div>

              <div className="premium-table-area">
                {/* LEFT SEATS */}
                <div className="premium-seats">
                  {Array.from({ length: nbSeats / 2 }, (_, i) => i + 1).map((n) => {
                    const key = `${index}-${n}`;
                    const place = tablePlaces.find(p => Number(p.chairCode) === n);
                    const active = selectedSeats[key];
                    const seatClass = placeStatusToClass(place?.status);
                    return (
                      <div
                        key={n}
                        className={`premium-seat ${active ? "active" : ""} ${seatClass}`}
                        onClick={() => handleSeatClick(index, String(tableNum), n, place?.status || "-1")}
                      >
                        {n}
                      </div>
                    );
                  })}
                </div>

                {/* TABLE RECT */}
                <div
                  className={`premium-table-rect ${isTableSelected ? "active" : ""} ${tableStatusClass(tableStatus)}`}
                  onClick={() => handleTableClick(index, String(tableNum), tableStatus, nbSeats)}
                />

                {/* RIGHT SEATS */}
                <div className="premium-seats">
                  {Array.from({ length: nbSeats / 2 }, (_, i) => i + 1 + nbSeats / 2).map((n) => {
                    const key = `${index}-${n}`;
                    const place = tablePlaces.find(p => Number(p.chairCode) === n);
                    const active = selectedSeats[key];
                    const seatClass = placeStatusToClass(place?.status);
                    return (
                      <div
                        key={n}
                        className={`premium-seat ${active ? "active" : ""} ${seatClass}`}
                        onClick={() => handleSeatClick(index, String(tableNum), n, place?.status || "-1")}
                      >
                        {n}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// Classes CSS pour status
function placeStatusToClass(status?: string) {
  switch (status) {
    case "0": return "seat-available";
    case "1": return "seat-reserved";
    default: return "seat-disabled";
  }
}

function tableStatusClass(status?: string) {
  switch (status) {
    case "0": return "table-available";
    case "1": return "table-reserved";
    default: return "table-disabled";
  }
}
